//K230���ߣ���ɫ��PC11 ��ɫ��PC10
//ESP32���ߣ�TX(GPIO17)->PA3(RX) RX(GPIO18)->PA2(TX)

/* --- 0. ����궨 ---
			PCA9685_SetServo(0, 90);
			PCA9685_SetServo(1, 90);
			PCA9685_SetServo(2, 90);
			PCA9685_SetServo(3, 90);
			PCA9685_SetServo(4, 90);
			PCA9685_SetServo(5, 90);
			PCA9685_SetServo(6, 90);
			PCA9685_SetServo(7, 90);
			PCA9685_SetServo(8, 90);
			PCA9685_SetServo(9, 90);
			PCA9685_SetServo(10, 90);
			PCA9685_SetServo(11, 90);
*/	


/* --- 1. ����վ�����벽̬ ---
			servo_init();  //��ʼ��
			delay_ms(1000);
			
			servo_standby(); //����
			delay_ms(1000);

			servo_close(); //��������
			delay_ms(1000);

			stand_fast(void); //����վ��
			delay_ms(1000);
			
			stand_slowly(); //����վ��
			delay_ms(1000);

			stand_hello(); //���к�
			delay_ms(1000);

			climb_stairs(void);
			climb_stairs_2(void);
*/	

/*--- 2. ���� TROT WALK ��̬ ---

			trot(9, TROT_CTRL_FORWARD);
			
			int g_stop_robot_flag = 0;
			trot_continuous(TROT_CTRL_FORWARD, &g_stop_robot_flag);
			
			turn_left(2);
      delay_ms(1000);

			turn_right(2);
      delay_ms(1000);
			
      turn_back(3); // ����3������
      delay_ms(1000); // �ȴ���һ��ָ��
			
			
			walk(50); 
			march(5);
*/

/* ---3. ��ESP32�������� ---
				//��ơ�������1
        const char* msg_to_esp = "1\n";
        UART2_Send_ArrayU8((uint8_t*)msg_to_esp, strlen(msg_to_esp));
				OLED_String(0, 8, (uint8_t*)msg_to_esp, 16);
        delay_ms(1000); // ��ʱ1��
				
				//�̵ơ�������2
        const char* msg_to_esp = "2\n";
        UART2_Send_ArrayU8((uint8_t*)msg_to_esp, strlen(msg_to_esp));
				OLED_String(0, 8, (uint8_t*)msg_to_esp, 16);
        delay_ms(1000); // ��ʱ1��
				
				//̨�ס�������3
        const char* msg_to_esp = "3\n";
        UART2_Send_ArrayU8((uint8_t*)msg_to_esp, strlen(msg_to_esp));
				OLED_String(0, 8, (uint8_t*)msg_to_esp, 16);
        delay_ms(1000); // ��ʱ1��
				
				//�ϰ���������4
        const char* msg_to_esp = "4\n";
        UART2_Send_ArrayU8((uint8_t*)msg_to_esp, strlen(msg_to_esp));
				OLED_String(0, 8, (uint8_t*)msg_to_esp, 16);
        delay_ms(1000); // ��ʱ1��
				
				//���������5
        const char* msg_to_esp = "5\n";
        UART2_Send_ArrayU8((uint8_t*)msg_to_esp, strlen(msg_to_esp));
				OLED_String(0, 8, (uint8_t*)msg_to_esp, 16);
        delay_ms(1000); // ��ʱ1��

*/

/*
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);

servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
servo_close();
delay_ms(1000);
delay_ms(1000);
servo_init();
delay_ms(1000);
delay_ms(1000);
*/

    // --- 4. GPS���� ---
		//UART1_Init(115200);   // ��ʼ��UART1����printf�������
		 //GPS_Debug_Init(); 


//	while(1)
//	{
//	
////		for(int i =10; i>0 ; i--)
////		{
////		trot_continuous(TROT_CTRL_FORWARD, &g_stop_robot_flag);
////		}
////		for(int i =10; i>0 ; i--)
////		{
////		side_hybrid_turn_right_continuous(&stop_flag);
////		}
////		for(int i =10; i>0 ; i--)
////		{
////		side_hybrid_turn_right_continuous(&stop_flag);
////		}
//		//march(1);
//    // ʾ��1��ִ����ת��ֱ���ⲿ�¼���stop_flag��Ϊ����ֵ
////    side_hybrid_turn_left_continuous(&stop_flag);
////		side_hybrid_turn_right_continuous(&stop_flag);
//		
////	turn_right(1);
////	turn_left(1);
////	trot(3, TROT_CTRL_FORWARD);
//	}


