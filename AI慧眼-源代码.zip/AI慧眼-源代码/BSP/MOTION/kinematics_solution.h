// kinematics_solution.h
#ifndef __KINEMATICS_SOLUTION_H
#define __KINEMATICS_SOLUTION_H

#include <stdint.h>
#include "predefine.h" // <<<<<< ���� predefine.h �Ի�ȡ���Ͷ���

#ifndef KINEMATICS_COMMON_TYPES_DEFINED // ��������ȷ����Щ����ֻ������һ��
#define KINEMATICS_COMMON_TYPES_DEFINED


#endif // KINEMATICS_COMMON_TYPES_DEFINED

// ��������ʹ�� predefine.h �е�����
uint8_t cycloid_coordinate_trot(float t, float lambda_c_c,
                                float xs, float xf, float xs_stance, float xf_stance,
                                float pn_1, float pn_2, float pn_3, float pn_4,
                                FootBodyCoord_t foot_coords_out[4]); // ������ʽ

uint8_t cycloid_coordinate_walk(float t, float lambda_c_c,
                                float xs, float xf, float xs_stance, float xf_stance,
                                FootBodyCoord_t foot_coords_out[4]);

////void march_coordinate(float t, float lambda_m_c,
//                      FootBodyCoord_t foot_coords_out[4]);

void attitude(const FootBodyCoord_t at_body_frame[4],
              FootRelHipCoord_t at_hip_frame_out[4]);

uint8_t inverse_kinematics(const FootRelHipCoord_t ik_input_hip_rel[4],
                           float ik_joint_angles_out[8]);

#endif // __KINEMATICS_SOLUTION_H

