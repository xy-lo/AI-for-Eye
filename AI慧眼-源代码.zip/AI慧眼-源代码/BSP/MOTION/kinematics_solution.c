#include "kinematics_solution.h"
#include "predefine.h" // ��ȡ ROBOT_L1_MM, ROBOT_L2_MM, ROBOT_HC_MM, ROBOT_TS_S, ROBOT_H_TROT_MM etc.
#include <math.h>

#ifndef M_PI
#define M_PI (3.14159265358979323846f)
#endif

// IK�㷨�ض���У׼ƫ���� (����Python kinematics_solution.py �е� inverse_kinematics ����)
static const float IK_THIGH_OFFSET_DEG_INTERNAL    = 48.3503f;
static const float IK_CALF_SUM_OFFSET_DEG_INTERNAL = 94.5407f;

// �ڲ���������
static float radians_to_degrees(float radians) {
    return radians * 180.0f / M_PI;
}

// ����������Ϊ��������һ�������İڶ�����߹켣 (�� start_x �� end_x)
static FootBodyCoord_t _generate_swing_phase(float normalized_time_in_swing, /* 0 to 1 */
                                             float start_x, float end_x, float lift_h) {
    FootBodyCoord_t point;
    float sigma = 2.0f * M_PI * normalized_time_in_swing; // sigma from 0 to 2*PI
    point.x = (end_x - start_x) * ((sigma - sinf(sigma)) / (2.0f * M_PI)) + start_x;
    point.y = lift_h * (1.0f - cosf(sigma)) / 2.0f;
    if (point.y < 0.0f) point.y = 0.0f;
    return point;
}

// ����������Ϊ��������һ��������֧����ֱ�߹켣 (�� start_x �� end_x)
static FootBodyCoord_t _generate_stance_phase(float normalized_time_in_stance, /* 0 to 1 */
                                              float start_x, float end_x) {
    FootBodyCoord_t point;
    point.x = start_x + (end_x - start_x) * normalized_time_in_stance;
    point.y = 0.0f;
    return point;
}

uint8_t cycloid_coordinate_trot(float t, float lambda_c_c, // lambda_c_c ���ڴ������������ڵ�ʱ���������ڵı�ֵ, ͨ����0.5
                                float xs_overall, float xf_overall, // ������ǰ������ĺ��޺�ǰ����
                                float xs_stance_unused, float xf_stance_unused, // �������������ܲ���ֱ������ʹ��
                                float pn_1, float pn_2, float pn_3, float pn_4,
                                FootBodyCoord_t foot_coords_out[4]) {
    float Ts_current = ROBOT_TS_S;
    float h_lift = ROBOT_H_TROT_MM;
    float half_Ts = Ts_current / 2.0f;

    if (t < 0.0f || t > Ts_current + 1e-3f) { /* ... error ... */ return 1;}

    // ȷ����ǰ�����ĸ������ڣ��Լ��ڸð������ڵ�ʱ��
    float time_in_half_cycle;
    int is_first_half_cycle_rf_lb_swing; // RF/LB �ڶ���LF/RB ֧��

    if (t < half_Ts) {
        time_in_half_cycle = t;
        is_first_half_cycle_rf_lb_swing = 1;
    } else {
        time_in_half_cycle = t - half_Ts;
        is_first_half_cycle_rf_lb_swing = 0;
    }

    float normalized_time = time_in_half_cycle / half_Ts;
    if (normalized_time < 0.0f) normalized_time = 0.0f;
    if (normalized_time > 1.0f) normalized_time = 1.0f;

    // �ڶ���켣���� (�Ӻ��޵�ǰ����)
    float swing_start_x = xs_overall; // ���� ROBOT_XS_TROT_MM
    float swing_end_x = xf_overall;   // ���� ROBOT_XF_TROT_MM

    // ֧����켣���� (��ǰ���޵�����)
    float stance_start_x = xf_overall;
    float stance_end_x = xs_overall;

    FootBodyCoord_t rf_pt, lf_pt, rb_pt, lb_pt;

    if (is_first_half_cycle_rf_lb_swing) {
        rf_pt = _generate_swing_phase(normalized_time, swing_start_x, swing_end_x, h_lift);
        lb_pt = _generate_swing_phase(normalized_time, swing_start_x, swing_end_x, h_lift);
        lf_pt = _generate_stance_phase(normalized_time, stance_start_x, stance_end_x);
        rb_pt = _generate_stance_phase(normalized_time, stance_start_x, stance_end_x);
    } else {
        rf_pt = _generate_stance_phase(normalized_time, stance_start_x, stance_end_x);
        lb_pt = _generate_stance_phase(normalized_time, stance_start_x, stance_end_x);
        lf_pt = _generate_swing_phase(normalized_time, swing_start_x, swing_end_x, h_lift);
        rb_pt = _generate_swing_phase(normalized_time, swing_start_x, swing_end_x, h_lift);
    }

    // Ӧ��ת��ϵ�� (pn_X ͨ��ֻӰ��X����)
    foot_coords_out[0].x = pn_1 * rf_pt.x; foot_coords_out[0].y = rf_pt.y;
    foot_coords_out[1].x = pn_2 * lf_pt.x; foot_coords_out[1].y = lf_pt.y;
    foot_coords_out[2].x = pn_3 * rb_pt.x; foot_coords_out[2].y = rb_pt.y;
    foot_coords_out[3].x = pn_4 * lb_pt.x; foot_coords_out[3].y = lb_pt.y;
    
    return 0;
}

// ��Ӧ Python: cycloid_coordinate_walk
uint8_t cycloid_coordinate_walk(float t, float lambda_c_c, // t is t_cycle_overall, lambda_c_c is lambda_swing_phase_ratio
                                float xs_swing, float xf_swing,
                                float xs_stance, float xf_stance_py, // Renamed from xf_stance for clarity with python logic
                                FootBodyCoord_t foot_coords_out[4]) {
    float Ts_curr = ROBOT_TS_WALK_S;
    float h_lift = ROBOT_H_WALK_MM;
    float Lambda_walk_val = lambda_c_c; // This is ROBOT_LAMBDA_WALK

    if (t < 0.0f || t > Ts_curr + 1e-3f) {
         for(int i=0; i<4; ++i) { foot_coords_out[i].x = 0; foot_coords_out[i].y = 0;}
        return 1;
    }

    float t_adj;
    float sigma_swing, sigma_stance_1, sigma_stance_2, sigma_stance_3, sigma_stance_4;
    float common_cycloid_factor;

    float swing_phase_duration_for_sigma = Ts_curr * Lambda_walk_val;
    float stance_phase_duration_for_sigma = Ts_curr * (1.0f - Lambda_walk_val);
    if(swing_phase_duration_for_sigma < 1e-6f) swing_phase_duration_for_sigma = 1e-6f;
    if(stance_phase_duration_for_sigma < 1e-6f) stance_phase_duration_for_sigma = 1e-6f;

    // Python leg order for c_c: x1,y1 (RF); x2,y2 (LF); x3,y3 (RB); x4,y4 (LB)
    if (t <= swing_phase_duration_for_sigma) { // Phase 1: RF swings
        t_adj = t;
        sigma_swing = 2.0f * M_PI * t_adj / swing_phase_duration_for_sigma;
        common_cycloid_factor = (sigma_swing - sinf(sigma_swing)) / (2.0f * M_PI);
        foot_coords_out[0].x = (xf_swing - xs_swing) * common_cycloid_factor + xs_swing;
        foot_coords_out[0].y = h_lift * (1.0f - cosf(sigma_swing)) / 2.0f;

        sigma_stance_3 = 2.0f * M_PI * t_adj / stance_phase_duration_for_sigma; // RB (Py leg 3)
        common_cycloid_factor = (sigma_stance_3 - sinf(sigma_stance_3)) / (2.0f * M_PI);
        foot_coords_out[2].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance; // Python xs_, xf_ -> C xs_stance, xf_stance_py
        foot_coords_out[2].y = 0.0f;

        sigma_stance_2 = 2.0f * M_PI * (t_adj + swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // LF (Py leg 2)
        common_cycloid_factor = (sigma_stance_2 - sinf(sigma_stance_2)) / (2.0f * M_PI);
        foot_coords_out[1].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[1].y = 0.0f;

        sigma_stance_4 = 2.0f * M_PI * (t_adj + 2.0f * swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // LB (Py leg 4)
        common_cycloid_factor = (sigma_stance_4 - sinf(sigma_stance_4)) / (2.0f * M_PI);
        foot_coords_out[3].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[3].y = 0.0f;
    }
    else if (t <= 2.0f * swing_phase_duration_for_sigma) { // Phase 2: LB swings
        t_adj = t - swing_phase_duration_for_sigma;
        sigma_swing = 2.0f * M_PI * t_adj / swing_phase_duration_for_sigma; // LB (Py leg 4)
        common_cycloid_factor = (sigma_swing - sinf(sigma_swing)) / (2.0f * M_PI);
        foot_coords_out[3].x = (xf_swing - xs_swing) * common_cycloid_factor + xs_swing;
        foot_coords_out[3].y = h_lift * (1.0f - cosf(sigma_swing)) / 2.0f;

        sigma_stance_1 = 2.0f * M_PI * t_adj / stance_phase_duration_for_sigma; // RF (Py leg 1)
        common_cycloid_factor = (sigma_stance_1 - sinf(sigma_stance_1)) / (2.0f * M_PI);
        foot_coords_out[0].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[0].y = 0.0f;

        sigma_stance_3 = 2.0f * M_PI * (t_adj + swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // RB (Py leg 3)
        common_cycloid_factor = (sigma_stance_3 - sinf(sigma_stance_3)) / (2.0f * M_PI);
        foot_coords_out[2].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[2].y = 0.0f;

        sigma_stance_2 = 2.0f * M_PI * (t_adj + 2.0f * swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // LF (Py leg 2)
        common_cycloid_factor = (sigma_stance_2 - sinf(sigma_stance_2)) / (2.0f * M_PI);
        foot_coords_out[1].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[1].y = 0.0f;
    }
    else if (t <= 3.0f * swing_phase_duration_for_sigma) { // Phase 3: LF swings
        t_adj = t - 2.0f * swing_phase_duration_for_sigma;
        sigma_swing = 2.0f * M_PI * t_adj / swing_phase_duration_for_sigma; // LF (Py leg 2)
        common_cycloid_factor = (sigma_swing - sinf(sigma_swing)) / (2.0f * M_PI);
        foot_coords_out[1].x = (xf_swing - xs_swing) * common_cycloid_factor + xs_swing;
        foot_coords_out[1].y = h_lift * (1.0f - cosf(sigma_swing)) / 2.0f;

        sigma_stance_4 = 2.0f * M_PI * t_adj / stance_phase_duration_for_sigma; // LB (Py leg 4)
        common_cycloid_factor = (sigma_stance_4 - sinf(sigma_stance_4)) / (2.0f * M_PI);
        foot_coords_out[3].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[3].y = 0.0f;

        sigma_stance_1 = 2.0f * M_PI * (t_adj + swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // RF (Py leg 1)
        common_cycloid_factor = (sigma_stance_1 - sinf(sigma_stance_1)) / (2.0f * M_PI);
        foot_coords_out[0].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[0].y = 0.0f;

        sigma_stance_3 = 2.0f * M_PI * (t_adj + 2.0f * swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // RB (Py leg 3)
        common_cycloid_factor = (sigma_stance_3 - sinf(sigma_stance_3)) / (2.0f * M_PI);
        foot_coords_out[2].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[2].y = 0.0f;
    }
    else { // Phase 4: RB swings (t <= Ts_curr)
        t_adj = t - 3.0f * swing_phase_duration_for_sigma;
        sigma_swing = 2.0f * M_PI * t_adj / swing_phase_duration_for_sigma; // RB (Py leg 3)
        common_cycloid_factor = (sigma_swing - sinf(sigma_swing)) / (2.0f * M_PI);
        foot_coords_out[2].x = (xf_swing - xs_swing) * common_cycloid_factor + xs_swing;
        foot_coords_out[2].y = h_lift * (1.0f - cosf(sigma_swing)) / 2.0f;

        sigma_stance_2 = 2.0f * M_PI * t_adj / stance_phase_duration_for_sigma; // LF (Py leg 2)
        common_cycloid_factor = (sigma_stance_2 - sinf(sigma_stance_2)) / (2.0f * M_PI);
        foot_coords_out[1].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[1].y = 0.0f;

        sigma_stance_4 = 2.0f * M_PI * (t_adj + swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // LB (Py leg 4)
        common_cycloid_factor = (sigma_stance_4 - sinf(sigma_stance_4)) / (2.0f * M_PI);
        foot_coords_out[3].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[3].y = 0.0f;

        sigma_stance_1 = 2.0f * M_PI * (t_adj + 2.0f * swing_phase_duration_for_sigma) / stance_phase_duration_for_sigma; // RF (Py leg 1)
        common_cycloid_factor = (sigma_stance_1 - sinf(sigma_stance_1)) / (2.0f * M_PI);
        foot_coords_out[0].x = (xf_stance_py - xs_stance) * common_cycloid_factor + xs_stance;
        foot_coords_out[0].y = 0.0f;
    }

    for(int i=0; i<4; ++i) {
        if(foot_coords_out[i].y < 0.0f) foot_coords_out[i].y = 0.0f;
    }
    return 0;
}

//// ��Ӧ Python: march_coordinate
//// t ��ӦPython�� t, lambda_m_c ��ӦPython�� lambda_m_c
//void march_coordinate(float t, float lambda_m_c,
//                      FootBodyCoord_t foot_coords_out[4]) {
//    float phase_duration = ROBOT_TS_S * lambda_m_c; // Ts from predefine
//    if (phase_duration < 1e-6f) phase_duration = 1e-6f;
//    float sigma = 2.0f * M_PI * t / phase_duration;

//    float y_lift_pair1 = ROBOT_H_MARCH_MM * (1.0f - cosf(sigma)) / 2.0f; // ROBOT_H_MARCH_MM from predefine
//    if (y_lift_pair1 < 0.0f) y_lift_pair1 = 0.0f;

//    float y_lift_pair2 = ROBOT_H_MARCH_MM - y_lift_pair1;
//    if (y_lift_pair2 < 0.0f) y_lift_pair2 = 0.0f;

//    // Leg order: RF, LF, RB, LB
//    foot_coords_out[0].x = 0.0f; foot_coords_out[0].y = y_lift_pair1; // RF (Python y1)
//    foot_coords_out[1].x = 0.0f; foot_coords_out[1].y = y_lift_pair2; // LF (Python y2)
//    foot_coords_out[2].x = 0.0f; foot_coords_out[2].y = y_lift_pair1; // RB (Python y3)
//    foot_coords_out[3].x = 0.0f; foot_coords_out[3].y = y_lift_pair2; // LB (Python y4)
//}

// ��Ӧ Python: attitude
void attitude(const FootBodyCoord_t at_body_frame[4],
              FootRelHipCoord_t at_hip_frame_out[4]) {
    for (int i = 0; i < 4; i++) {
        at_hip_frame_out[i].x_rh = at_body_frame[i].x;
        at_hip_frame_out[i].y_rh = at_body_frame[i].y - ROBOT_HC_MM; // ROBOT_HC_MM from predefine
    }
}

// ����IK���ļ��� (��֮ǰ�汾��ͬ)
static uint8_t _calculate_single_leg_ik_degrees(float x, float y, float* theta1_deg_out, float* theta2_deg_out) {
    float l1 = ROBOT_L1_MM;
    float l2 = ROBOT_L2_MM;
    float d_sq = x * x + y * y;
    float d = sqrtf(d_sq);

    if (d > (l1 + l2) - 1e-6f) { if (d > (l1+l2) + 1e-6f) return 1; d = l1+l2; }
    if (d < fabsf(l1 - l2) + 1e-6f) { if (d < fabsf(l1-l2) - 1e-6f ) return 1; d = fabsf(l1-l2); }
    d_sq = d*d;

    float cos_theta2_val_numerator = (d_sq - l1 * l1 - l2 * l2);
    float cos_theta2_val_denominator = (-2.0f * l1 * l2);
    if (fabsf(cos_theta2_val_denominator) < 1e-9f) { return 1; }
    float cos_theta2_val = cos_theta2_val_numerator / cos_theta2_val_denominator;
    if (cos_theta2_val > 1.0f) cos_theta2_val = 1.0f;
    if (cos_theta2_val < -1.0f) cos_theta2_val = -1.0f;
    float theta2_rad_geom = M_PI - acosf(cos_theta2_val);

    float cos_fai1_numerator = (l1 * l1 + d_sq - l2 * l2);
    float cos_fai1_denominator = (2.0f * l1 * d);
    float theta1_rad_geom;
    if (d < 1e-6f) {
        theta1_rad_geom = -M_PI / 2.0f;
        theta2_rad_geom = M_PI;
    } else if (fabsf(cos_fai1_denominator) < 1e-9f) {
        return 1;
    } else {
        float cos_fai1 = cos_fai1_numerator / cos_fai1_denominator;
        if (cos_fai1 > 1.0f) cos_fai1 = 1.0f;
        if (cos_fai1 < -1.0f) cos_fai1 = -1.0f;
        float fai1_rad = acosf(cos_fai1);
        float angle_to_target = atan2f(y, x);
        if (x > 1e-6f) {
            theta1_rad_geom = M_PI - fabsf(angle_to_target) - fai1_rad;
        } else if (x < -1e-6f) {
            theta1_rad_geom = fabsf(angle_to_target) - fai1_rad;
        } else {
            if (y >= 0.0f) theta1_rad_geom = (M_PI / 2.0f) - fai1_rad;
            else theta1_rad_geom = (-M_PI / 2.0f) - fai1_rad;
        }
    }

    float theta1_deg_geom_raw = radians_to_degrees(theta1_rad_geom);
    float theta2_deg_geom_raw = radians_to_degrees(theta2_rad_geom);

    *theta1_deg_out = theta1_deg_geom_raw - IK_THIGH_OFFSET_DEG_INTERNAL;
    *theta2_deg_out = (*theta1_deg_out) + theta2_deg_geom_raw - IK_CALF_SUM_OFFSET_DEG_INTERNAL;
    return 0;
}

// ��Ӧ Python: inverse_kinematics
uint8_t inverse_kinematics(const FootRelHipCoord_t ik_input_hip_rel[4], float ik_joint_angles_out[8]) {
    uint8_t global_ik_status = 0;
    for (int leg_idx = 0; leg_idx < 4; leg_idx++) {
        float x_hip = ik_input_hip_rel[leg_idx].x_rh;
        float y_hip = ik_input_hip_rel[leg_idx].y_rh;
        float thigh_angle, calf_angle;
        uint8_t single_leg_status = _calculate_single_leg_ik_degrees(x_hip, y_hip, &thigh_angle, &calf_angle);
        if (single_leg_status != 0) {
            global_ik_status |= (1 << leg_idx);
            ik_joint_angles_out[leg_idx * 2 + 0] = 0.0f;
            ik_joint_angles_out[leg_idx * 2 + 1] = 0.0f;
        } else {
            ik_joint_angles_out[leg_idx * 2 + 0] = thigh_angle;
            ik_joint_angles_out[leg_idx * 2 + 1] = calf_angle;
        }
    }
    return global_ik_status;
}

